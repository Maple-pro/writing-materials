export const es = {};
