export const fr = {};
